#---------------------------------------------------#
# Title: Create To-Do List
# Purpose:  Program creates initial text file from
#           which todolist.py program will initially
#           read.
# Dev: Marie Augustine
# Date: April 26, 2019
# ChangeLog:
# MarieAugustine, 4/26/2019, Created script
#---------------------------------------------------#

# Creates simple text file from which todolist.py will initially read
objfile = open("todo.txt","w")
objfile.write("Clean House,low\n")
objfile.write("Pay Bills,high")
objfile.close()